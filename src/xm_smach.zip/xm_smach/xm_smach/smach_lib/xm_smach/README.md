checkturn.py   + # 11 
