import rospy
import os
from smach import StateMachine
from smach_ros import IntrospectionServer

import math









class 

class GPSR():
    




if __name__== "main":
    try:
        GPSR()
    except:
        rospy.logerr(error)
        print("error error error")