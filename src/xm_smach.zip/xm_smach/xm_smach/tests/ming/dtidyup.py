#!/usr/bin/env python
# encoding:utf8

import rospy
from smach import StateMachine
from smach_ros import IntrospectionServer
from smach_special.TidyUp_lib import *
from smach_special.gpsr import Wait_trace, RunNode
from smach_compose.compose import *
from smach_common.common import *


class Tidy():
    def __init__(self):
        rospy.init_node("TidyUp_Smach")
        rospy.on_shutdown(self.shutdown)
        rospy.logerr("Welcome to TidyUp!")
        self.smach_bool = False

