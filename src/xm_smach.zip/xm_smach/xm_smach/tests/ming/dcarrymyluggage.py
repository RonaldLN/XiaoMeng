#!/usr/bin/env python
# encoding:utf8

from os import abort
import rospy
from smach import StateMachine
from smach_ros import IntrospectionServer
from geometry_msgs.msg import *
from smach_special.gpsr import *
from smach_common.common import *
from smach_compose.compose import *

class Carry():
    def __init__(self):
        rospy.init_node("carrymylagguge_smach")
        # rospy.on_shutdown(self.shutdown) # will be called before Node begins teardown.
        # rospy.logerr("welcome to carry")
        # self.smach_bool = False

        # Re-enter the arena 
        self.xm_Nav = StateMachine(outcomes=['succeed','aborted','error'],
                                    input_keys=['target','current_task'])
        with self.xm_Nav:
            self.xm_Nav.userdata.pose_xm = Pose() #from geometry_msgs.msg
            self.xm_Nav.userdata.target_mode = 1  #当 mode == 1 是返回目标的位置

            StateMachine.add('GETTARGET', # get pose_xm
                            GetTarget(), # from smach_special.gpsr, 修改(获取)userdata.current_target
                            transitions={'succeeded':'GO','aborted':'aborted','error':'error'},
                            remapping={'target': 'target', 'current_task': 'current_task',
                                        'current_target': 'pos_xm', 'mode': 'target_mode'}  # 相当于将current_target赋值给pos_xm
                            )
            StateMachine.add('GO',
                            NavStack(), # from smach_common.common , move to pose_xm
                            transitions={'succeeded': 'SPEAK',
                                          'aborted': 'GO', 'error': 'error'},
                            remapping={'pos_xm': 'pos_xm'}
                            )

            self.xm_Nav.userdata.sentences = 'I have arrived here'

            StateMachine.add('SPEAK',
                            Speak(), # from smach_common.common , 使用语音的服务，开一个子进程，播放音频
                            transitions={'succeeded': 'succeeded', 'error': 'error'},
                            remapping={'sentences':'sentence'}
                            )

        #----FOLLOW-----#
        # xm_Follow包括两个并发状态，FOLLOW和STOP
        # STOP用于语音获取stop信号
        # FOLLOW包装了FindPeople().find_people_监视器和meta_nav
        # 当找到人需要移动时，状态转移到meta_nav
        # meta_nav后,再继续进入监视状态
        # meta_nav是一个并发状态机，包装了NAV和WAIT
        # WAIT用于记录时间引发time_over
        # nav成功或中止后，与time_over一起进入继续找人状态

        self.xm_Follow = Concurrence(
                                    
        )
        with self.xm_Follow:
            self.meta_Follow = StateMachine(
                ['succeeded', 'aborted', 'preempted'])

            with self.meta_Follow:
                self.meta_Follow.userdata.pos_xm = Pose()
                self.meta_Follow.userdata.rec = 0.2

                StateMachine.add('FIND',
                                LegTracker0().tracker, # from smach_compose.compose, 摄像头给订阅的话题发消息来跟踪人，在follow中
                                transitions={
                                     'invalid': 'WAIT', 'valid': 'FIND', 'preempted': 'preempted'},
                                remapping={'pos_xm': 'pos_xm'}
                                )

                StateMachine.add('WAIT',
                                Wait(),
                                transitions={'succeeded': 'META_NAV', 'error': 'META_NAV'})
                
                self.meta_nav = Concurrence(outcomes=['time_over', 'get_pos', 'aborted'],
                                            default_outcome='aborted',
                                            outcome_map={'time_over': {'WAIT': 'succeeded'},
                                                         'get_pos': {'NAV': 'succeeded'},
                                                         'aborted': {'NAV': 'aborted'}},
                                            child_termination_cb=self.nav_child_cb,
                                            input_keys=['pos_xm'])
                with self.meta_nav:
                    Concurrence.add('NAV', NavStack0(), remapping={
                                    'pos_xm': 'pos_xm'})  # 跟随人
                    Concurrence.add('WAIT', Wait_trace())  # 以一定频率发移动指令
                StateMachine.add('META_NAV',
                                 self.meta_nav,
                                 transitions={'get_pos': 'FIND', 'time_over': 'FIND', 'aborted': 'FIND'})
            Concurrence.add('FOLLOW', self.meta_follow)
            Concurrence.add('STOP', CheckStop())
            # Concurrence.add('RUNNODE',RunNode())#开启跟随人的图像节点

        # PICK_UP
        # RUNNODE_IMG-->GETNAME-->GET_POS-->NAV-->FIND-->POS_JUS-->NAV-->RUNNODE_IMG-->FIND-->POS_JUS-->PICK-->SPEAK
        # 运行图像节点，获取物体名字和大物体位置后，nav到大物体位置，然后用图像找物体，然后用pos_jus得出适宜抓取的坐标，nav后继续循环一次
        # 在此之后，进行抓取
        # 如果上面的图像没有找到物体，则通过speak进行错误反馈
         
        self.xm_Pick_up = StateMachine(outcomes=['succeeded', 'aborted', 'error'],
                                       input_keys=['target', 'current_task'])  
        with self.xm_Pick_up:
            






            StateMachine.add('FIND_1',
                            GetObjectPosition(),
                            transitions={'succeeded': 'GETPICKPOSE', 'error': 'error'}
                            )
            StateMachine.add('GETPICKPOSE',
                            GetPickPos(),
                            transitions={'succeeded': 'NAVTOPICKPOS', 'error': 'error'}
                            )
            StateMachine.add('NAVTOPICKPOS',
                             NavStack(),
                             transitions={
                                 'succeeded': 'FIND_2', 'aborted': 'NAVTOPICKPOS', 'error': 'error'},
                             remapping={"pos_xm": 'pick_pos'}
                             )
            StateMachine.add('FIND_2',
                             GetObjectPosition(),
                             transitions={'succeeded': 'TARGET_POINT_JUSFY', 'error': 'error'})
            StateMachine.add('TARGET_POINT_JUSFY',
                             TargerPosReload(),
                             transitions={'succeeded': 'PICK', 'error': 'error'})
            StateMachine.add('PICK',
                             ArmStack(),
                             transitions={'succeeded': 'NAV_BACK', 'error': 'error'})
            self.xm_Pick_up.userdata.distance = -0.2
            StateMachine.add('NAV_BACK',
                             GoAhead(),
                             transitions={
                                 'succeeded': 'succeeded', 'error': 'error'},
                             remapping={'move_len': 'distance'})


        # Put_down
        self.xm_Put_dowm = StateMachine(
            outcomes=['succeeded', 'aborted', 'error'])
        with self.xm_Put_dowm:
            self.xm_Put_down.userdata.arm_waypoints=[[0.2,0,0.5,0]]
            self.xm_Put_down.userdata.commond = 0 # 0:open 1:close
            StateMachine.add('ARM_MOVE',
                             ArmTrajectory(),  # 控制爪子（打开）
                             transitions={'succeeded': 'PLACE','error': 'error'})
            StateMachine.add('PLACE',
                             GripperCommond(),  # 控制爪子（打开）
                             transitions={'succeeded': 'succeeded','error': 'error'})

        #  顶层状态机
        self.xm_Carry = StateMachine(
            outcomes=['succeeded', 'aborted', 'error'])

        with self.xm_Carry:


            StateMachine.add('RECEIVE_TASKS',
                             GetTask(),
                             transitions={'succeeded': 'GET_NEXT_TASK',
                                          'aborted': 'RECEIVE_TASKS', 'error': 'error'},
                             remapping={'target': 'target', 'action': 'action',
                                        'task_num': 'task_num', 'answer': 'answer'})   
            StateMachine.add('GET_NEXT_TASK',
                             NextDo(),
                             transitions={'succeeded': 'BACK_DOOR',
                                          'aborted': 'aborted',
                                          'error': 'error',
                                          'go': 'GO',
                                          'follow': 'CLOSE_GRIPPER',  # open the camera first
                                          'get': 'PICK_UP',
                                          'release': 'PUT_DOWN'},
                             remapping={'action': 'action',
                                        'current_task': 'current_task',
                                        'task_num': 'task_num'}
                             )
            StateMachine.add('BACK_DOOR',
                             NavStack(),
                             transitions={'succeeded': 'succeeded',
                                          'aborted': 'BACK_DOOR', 'error': 'error'},
                             remapping={'pos_xm': 'start_pos'}
                             )
            StateMachine.add('GO_OUT',
                             NavStack(),
                             transitions={'succeeded': 'succeeded',
                                          'aborted': 'aborted', 'error': 'error'},
                             remapping={"pos_xm": 'waypoint'}
                             )
            # add all the task smach
            StateMachine.add('GO',
                             self.xm_Nav,
                             remapping={'target': 'target',
                                        'current_task': 'current_task'},
                             transitions={'succeeded': 'RECEIVE_TASKS', 'aborted': 'GO'})
            StateMachine.add('CLOSE_GRIPPER',
                             GripperCommond(),
                             transitions={'succeeded': 'SPEAK_START',
                                          'error': 'CLOSE_GRIPPER'},
                             remapping={'commond': 'gripper_close'})
            StateMachine.add('SPEAK_START',  # 念一句话
                             Speak(),
                             transitions={'succeeded': 'RUNNODE',
                                          'aborted': 'SPEAK_START'},
                             remapping={'sentences': 'start_follow'})
            StateMachine.add('RUNNODE',
                             RunNode(),
                             transitions={'succeeded': 'FOLLOW', 'aborted': 'RUNNODE'})
            StateMachine.add('FOLLOW',
                             self.xm_Follow,
                             transitions={'succeeded': 'SPEAK_FINISH', 'aborted': 'FOLLOW'})
            StateMachine.add('SPEAK_FINISH',  # 念一句话
                             Speak(),
                             transitions={'succeeded': 'RECEIVE_TASKS',
                                          'aborted': 'SPEAK_FINISH'},
                             remapping={'sentences': 'finish'})
            StateMachine.add('PICK_UP',
                             self.xm_Pick_up,
                             remapping={'target': 'target',
                                        'current_task': 'current_task'},
                             transitions={'succeeded':'RECEIVE_TASKS','aborted': 'PICK_UP'})
            StateMachine.add('PUT_DOWN',
                             self.xm_Put_down,
                             transitions={'succeeded': 'RELEASE_NAV', 'aborted': 'PUT_DOWN'})
            StateMachine.add('RELEASE_NAV',
                             NavStack(),
                             transitions={'succeeded': 'succeeded',
                                          'aborted': 'RELEASE_NAV', 'error': 'RELEASE_NAV'},
                             remapping={'pos_xm': 'start_pos'})
            
        intro_server = IntrospectionServer('xm_Carry', self.xm_Carry, '/XM_ROOT')
        intro_server.start()
        out = self.xm_Carry.execute()
        intro_server.stop()

    def shutdown(self):
        if self.smach_bool == True:
            rospy.loginfo('smach succeeded')
        else:
            rospy.loginfo('smach error')

    # return True down
    def child_cb(self, outcome_map):
        if outcome_map['STOP'] == 'stop':
            rospy.logwarn(
                '---------get the signal of stop,stop tracing---------')
            pid = get_pid("people_tracking")
            subprocess.Popen(['kill', '-9', pid], shell=True)
            return True
        elif outcome_map['STOP'] == 'aborted':
            rospy.logerr('the stop state meet error!')
            return True

        if outcome_map['FOLLOW']:
            rospy.logerr('the follow state meet error!')
            return True
        return False

    def nav_child_cb(self, outcome_map):
        if outcome_map['WAIT'] == 'succeeded':
            rospy.logwarn('get the pos again')
            return True
        elif outcome_map['NAV'] == 'succeeded':
            return True
        elif outcome_map['NAV'] == 'aborted':
            return True
        else:
            print(outcome_map)
            return False

    # use for concurrence
if __name__ == "__main__":
    try:
        Carry()
    except:
        rospy.logerr(e)