
Author: yishui
Date: 2022-06-28

LastEditTime: 2022-06-28 20:48:58
LastEditors: yishui

Function: 
晓萌控制策略代码，通过statemachine来组织晓萌的行为

Folder:
  1.smach_lib:状态机类
  2.smach_log:状态机编写流程
  3.tests:测试和比赛用状态机
Summary:
对状态机代码中常用的类实现了封装，方便以后使用。

Use:
  gpsr:
    rosrun xm_smach gpsr.py