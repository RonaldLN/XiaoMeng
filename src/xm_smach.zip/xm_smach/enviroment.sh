sudo chmod 777 xm_smach/tests/jacy/*/*
sudo chmod 777 xm_smach/tests/jacy/*/*/*

