控制机械臂   topic:  /set_arm_joints_pos

控制爪子    service:  /mobile_base/gripper_command  
                      其中，request中的command1和command2分别为两个爪子的媒介，顺序取决于电子组
                      
                      
获取爪子状态  service ： /mobile_base/GetClaw
                      其中  req中的num为爪子的标号，取值范围1,2，res为对应爪子的状态
                      
设置脖子    service:  /mobile_base/SetNeck
                      传入的两个数据分别的为两个自由度的对应值，顺序取决于电子组
                      
获取脖子状态    service：    /mobile_base/GetNeck
                          返回脖子的两个角度值
                      
