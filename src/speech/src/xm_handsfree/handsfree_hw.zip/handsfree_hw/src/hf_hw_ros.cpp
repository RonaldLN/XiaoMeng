/***********************************************************************************************************************
* Copyright (c) Hands Free Team. All rights reserved.
* FileName: hf_link.cpp
* Contact:  QQ Exchange Group -- 521037187
* Version:  V2.0
*
* LICENSING TERMS:
* The Hands Free is licensed generally under a permissive 3-clause BSD license.
* Contributions are required to be made under the same license.
*
* History:
* <author>      <time>      <version>      <desc>
* luke liao       2016.4.1   V1.0           creat this file
*
* Description: handsfree ros ros_control framework
***********************************************************************************************************************/
/********************


                *******************/

#include <handsfree_hw/hf_hw_ros.h>

namespace handsfree_hw
{
uint8_t plat_flag = 0;

HF_HW_ros::HF_HW_ros(ros::NodeHandle &nh, std::string url, std::string config_addr, bool use_sim_) : hf_hw_(url, config_addr, use_sim_),
                                                                                                     nh_(nh)
{
    //get the parameter
    //设置这个以后就不用spin了
    //tempi=0;
    sim_xm_ = use_sim_;
    //：从参数服务器获取launch文件中设定的同名参数sim_xm
    if (!sim_xm_)
    {

        ROS_ERROR("Started xm_robot connection on port /dev/ttyUSB0");
    }
    else
        ROS_ERROR("xm_robot being simulated.");
    nh_.setCallbackQueue(&queue_);
    base_mode_ = "2-wheel";
    with_arm_ = true;
    controller_freq_ = 50; //50
    nh_.getParam("base_mode", base_mode_);
    nh_.getParam("/handsfree_hw_node/with_arm", with_arm_);
    nh_.getParam("freq", controller_freq_);
    // robot_state_publisher_ = nh_.advertise<handsfree_msgs::robot_state>("robot_state", 10);////////////////////

    ultrasound_pub = nh_.advertise<sensor_msgs::Range>("UltraSoundPublisher", 10); //话题名

    x_ = y_ = theta_ = x_cmd_ = y_cmd_ = theta_cmd_ = 0.0;
    x_vel_ = y_vel_ = theta_vel_ = 0.0;

    gripper_cmd_hw_[0] = 2;
    gripper_cmd_hw_[1] = 2;
    

    //超声波数据部分初始化
    std::string ultra = "/ultrasonic";
    for (int i = 0; i < 14; i++)
    {
        std_msgs::Header header;
        //header.stamp = ros::Time::now();
        //header.frame_id = ultra + std::to_string(i);
        //header.frame_id="/base_footprint";
        ultraMSG[i].header = header;
        ultraMSG[i].radiation_type = sensor_msgs::Range::ULTRASOUND;

        ultraMSG[i].field_of_view = 0.088; //约5度
        ultraMSG[i].min_range = 0;
        ultraMSG[i].max_range = 1.2; //1.2米的数据有效

        //ultraMSG[i].range = ultradound[i];
    }

    arm_joints_pos_subscriber_ = nh_.subscribe<std_msgs::Float32MultiArray>("/set_arm_joints_pos",5,boost::bind(&HF_HW_ros::callBackSetArmJointsPos,this,_1));

    test_pub = nh_.advertise<std_msgs::Float32MultiArray>("/set_arm_joints_pos",1000);
    /*
    head1_servo1_cmd_ = head1_servo2_cmd_  = head2_servo1_cmd_ = head2_servo2_cmd_ = 0.0;
    head1_servo1_pos_ = head1_servo2_pos_ = head1_servo1_vel_ = head2_servo1_vel_ = head1_servo1_eff_ = head2_servo1_eff_ = 0;
    */
    //real_theta = -theta_;real_theta_cmd = theta_cmd_;real_theta_vel = theta_vel_;
    //register the hardware interface on the robothw
    hardware_interface::BaseStateHandle base_state_handle("mobile_base", &x_, &y_, &theta_, &x_vel_, &y_vel_, &theta_vel_); //7.23电子组更改坐标系，为协调故在软件与电子交互层更改xy顺序
    base_state_interface_.registerHandle(base_state_handle);
    registerInterface(&base_state_interface_);
    hardware_interface::BaseVelocityHandle base_handle(base_state_handle, &x_cmd_, &y_cmd_, &theta_cmd_);
    base_velocity_interface_.registerHandle(base_handle);
    registerInterface(&base_velocity_interface_);

    //if (with_arm_)
    //{
    arm_pos_.resize(10, 0.0);
    arm_vel_.resize(10, 0.0);
    arm_eff_.resize(10, 0.0);
    arm_cmd_.resize(10, 0.0); //第六个数表示对plat_height的命令,第五个数表示对wrist_angle的命令
    std::vector<std::string> joint_names;
   
    joint_names.push_back("arm_joint_4");
    joint_names.push_back("arm_joint_3");
    joint_names.push_back("arm_joint_1");
    joint_names.push_back("arm_joint_0");
    joint_names.push_back("arm_joint_2");
    joint_names.push_back("arm_joint_5");

    // the lifting_controller use the same interface with the arm
    // but use different controller
    joint_names.push_back("lifting_joint"); 

    joint_names.push_back("camera_joint_0");
    joint_names.push_back("camera_joint_1");
    joint_names.push_back("active_finger_joint");

    ROS_INFO("registerHandle begin");

    for (int i = 0; i < arm_pos_.size(); i++)
    {
        //get the joint name
        hardware_interface::JointStateHandle arm_state_handle(joint_names[i], &arm_pos_[i], &arm_vel_[i], &arm_eff_[i]);
        joint_state_interface_.registerHandle(arm_state_handle);
        //hardware_interface::JointHandle arm_handle(arm_state_handle, &arm_cmd_[i]);
        //position_joint_interface_.registerHandle(arm_handle);
        //ROS_WARN("registerHandle %s",i);
    }

/*
    gripper_pos_.resize(2, 0.0);
    gripper_vel_.resize(2, 0.0);
    gripper_eff_.resize(2, 0.0);
    gripper_cmd_.resize(2, 0.0);
    std::vector<std::string> gripper_names;
    gripper_names.push_back("joint_left_finger");
    gripper_names.push_back("joint_right_finger");
    for (int i = 0; i < gripper_pos_.size(); i++)
    {
        //get the joint name
        hardware_interface::JointStateHandle gripper_state_handle(gripper_names[i], &gripper_pos_[i], &gripper_vel_[i], &gripper_eff_[i]);
        joint_state_interface_.registerHandle(gripper_state_handle);
        hardware_interface::GripperCmdHandle gripper_handle(gripper_state_handle, &gripper_cmd_hw_, &gripper_cmd_[i]);
        gripper_cmd_interface_.registerHandle(gripper_handle);
    }
*/
    registerInterface(&joint_state_interface_);
    //registerInterface(&position_joint_interface_);
    //registerInterface(&gripper_cmd_interface_);

    //}

    /*hardware_interface::HeadServoStateHandle head_servo_state_handle("xm_head",&head_servo_yaw_pos_,&head_servo_pitch_pos_);
    head_servo_state_interface_.registerHandle(head_servo_state_handle);
    registerInterface(&head_servo_state_interface_);
    hardware_interface::HeadServoHandle head_servo_handle(head_servo_state_handle,&head_servo_yaw_cmd_,&head_servo_pitch_cmd_);
    head_servo_cmd_interface.registerHandle(head_servo_handle);
    
    registerInterface(&head_servo_cmd_interface);*/

    //write_update_thread_.start(&HF_HW_ros::writeBufferUpdate, *this);
    //read_update_thread_.start(&HF_HW_ros::readBufferUpdate, *this);

    if (!sim_xm_)
    {
        if (hf_hw_.initialize_ok())
        {
            ROS_INFO("system initialized succeed, ready for communication");
        }
        else
        {
            ROS_ERROR("hf link initialized failed, please check the hardware");
        }
    }
    else
        ROS_ERROR("hf link initialized is no need, take it easy");
}
// 上次比赛写的简易版本控制方法，还是可以用的
// 本来是写了一个控制器，但是偶尔会出现智能指针错误导致程序崩溃，所以保险起见还是暂时先用service来实现对gripper的控制
bool HF_HW_ros::serviceCallBack(xm_msgs::xm_Gripper::Request &req, xm_msgs::xm_Gripper::Response &res)
{
    // 0:close  1:open  2:normal
    
    gripper_cmd_hw_[0] = req.command1;
    gripper_cmd_hw_[1] = req.command2;
    
    //if(gripper_cmd_hw_[0]=='1')
    //    std::cout<<1<<std::endl;
   // else if(gripper_cmd_hw_==1)
     //   std::cout<<2<<std::endl;
    

    //float gripper_state = (gripper_cmd_hw_ == '1') ? 0.0 : -0.01;
    // update the gripper_state
    //gripper_cmd_[0] = gripper_state;
    //gripper_cmd_[1] = gripper_state;
  
    res.result = true;
    return true;
}
bool HF_HW_ros::SoundSourceCallBack(xm_msgs::SoundSource::Request &req, xm_msgs::SoundSource::Response &res)
{
    ros::Time begin = ros::Time::now();

    sound_angle_ = 0.0;
    hf_hw_.getRobotAbstract()->sound_angle = 0.0;
    sound_start_ = true;
    //std::cout<<"sound_start_=true"<<std::endl;

    //当10s后仍为收到数据时，终端等待，返回404
    while (sound_angle_ == 0.0)
        if (ros::Time::now().sec - begin.sec >= 10)
            break;
    if (ros::Time::now().sec - begin.sec >= 10)
        res.angle = 404;
    else
        res.angle = sound_angle_;

    sound_angle_ = 0.0;
    hf_hw_.getRobotAbstract()->sound_angle = 0.0;
    sound_start_ = false;
    return true;
}
bool HF_HW_ros::GetClawCallBack(xm_msgs::ClawBack::Request &req, xm_msgs::ClawBack::Response &res)
{
    int choose = req.num - 1; 

    res.state = claw_state_back_[choose];

    return true;
}
    
bool HF_HW_ros::SetNeckCallBack(xm_msgs::set_neck::Request &req, xm_msgs::set_neck::Response &res)
{
    hf_hw_.getRobotAbstract()->expect_neck_state.servo1 = req.setNeck0;
    hf_hw_.getRobotAbstract()->expect_neck_state.servo2 = req.setNeck1;

    res.state=true;
    return true;
}
bool HF_HW_ros::GetNeckCallBack(xm_msgs::get_neck::Request &req, xm_msgs::get_neck::Response &res)
{
    res.getNeck0 = neck[0];
    res.getNeck1 = neck[1];

}

bool HF_HW_ros::platCallBack(xm_msgs::xm_Plat::Request &req,xm_msgs::xm_Plat::Response &res)
{
    plat_height_command=req.height;

    res.result = true;

    return true;
 }

void HF_HW_ros::callBackSetArmJointsPos(const std_msgs::Float32MultiArray::ConstPtr &msg)
{
    arm_cmd_[0] = msg->data[4];
    arm_cmd_[1] = msg->data[3];
    arm_cmd_[2] = msg->data[1];
    arm_cmd_[3] = msg->data[2];   
    arm_cmd_[4] = msg->data[0];
    arm_cmd_[5] = msg->data[5];
    //std::cout<<arm_cmd_[0]<<" "<<arm_cmd_[1]<<" "<<arm_cmd_[2]<<" "<<arm_cmd_[3]<<" "<<arm_cmd_[4]<<" "<<arm_cmd_[5]<<std::endl;
}

void HF_HW_ros::publishUltraSound()
{
    for (int i = 0; i < 14; i++)
    {
        ros::Time begin =ros::Time::now();
       
        ultraMSG[i].header.stamp=begin;
        //ultraMSG[i].header.stamp=begin;
        
        //ultraMSG[i].range = ultrasound[i];      //ultrasound[i];
        ultraMSG[i].range=-1;

        if(ultraMSG[i].range>1.2)
            ultraMSG[i].range=1.2;
        ultraMSG[i].header.frame_id="ultrasonic"+std::to_string(i)+"_link";

        //ultrasound_pub.publish(ultraMSG[i]);

        //ultraTransform.sendTransform(
        //    tf::StampedTransform(
        //        tf::Transform(tf::Quaternion(0,0,0,1),tf::Vector3(0.2356,ultra_y[i],-0.05675)),
        //        begin,"base_link","ultrasonic"+std::to_string(i)+"_link"));
    }
}

void HF_HW_ros::mainloop()
{
    ros::CallbackQueue cm_callback_queue;
    ros::NodeHandle cm_nh("mobile_base");
    cm_nh.setCallbackQueue(&cm_callback_queue);
    controller_manager::ControllerManager cm(this, cm_nh); //传入一个和controller同一工作空间的ros句柄

    ros::AsyncSpinner cm_spinner(1, &cm_callback_queue); //:mmp你这里开个1线程是要闹哪样
    ros::AsyncSpinner hw_spinner(1, &queue_);

    if (with_arm_)
        server_ = cm_nh.advertiseService("gripper_command", &HF_HW_ros::serviceCallBack, this);
    plat_server_ =cm_nh.advertiseService("plat_command",&HF_HW_ros::platCallBack,this);
    //std::cout<<"1111111111111111111111"<<std::endl;
    SoundSource_srv_ = cm_nh.advertiseService("SoundSource", &HF_HW_ros::SoundSourceCallBack, this);
    getclaw_srv_ = cm_nh.advertiseService("GetClaw",&HF_HW_ros::GetClawCallBack,this);

    setNeck_srv_ = cm_nh.advertiseService("SetNeck",&HF_HW_ros::SetNeckCallBack,this);
    getNeck_srv_ = cm_nh.advertiseService("GetNeck",&HF_HW_ros::GetNeckCallBack,this);

    ros::Rate loop(controller_freq_);
    //ros::Rate hehe(20);//去你mmp的呵呵
    cm_spinner.start();
    hw_spinner.start();

    int count = 0;
    ros::Time currentTime = ros::Time::now();
    while (ros::ok())
    {
        if (!sim_xm_)
        {
            hf_hw_.checkHandshake();
            /*// if(!hf_hw_.updateCommand(READ_GLOBAL_COORDINATE, count))
                hf_hw_.updateCommand(READ_GLOBAL_COORDINATE, count);
            // if(!hf_hw_.updateCommand(READ_ROBOT_SPEED, count))
                hf_hw_.updateCommand(READ_ROBOT_SPEED, count);
           
            // hf_hw_.updateCommand(READ_HEAD_1, count);
            if (with_arm_){
                hf_hw_.updateCommand(READ_ARM_TOTAL, count);/////
            //2017.7.9注释下述代码,因为stm32未写platform的数据反馈 
                hf_hw_.updateCommand(READ_PLAT, count);

               
            }
            // if(!hf_hw_.updateCommand(SET_ROBOT_SPEED, count))
            /////  
            */
            readBufferUpdate();

            //std::cout<< "* *"<<std::endl;
            hf_hw_.updateWriteCommand(SET_ROBOT_SPEED, count);
            //std::cout<<x_cmd_<<" "<<y_cmd_<<" "<<theta_cmd_<<std::endl;
            //ROS_INFO("head1_servo1_cmd_ = %.4f  head1_servo2_cmd_=%.4f" , head1_servo1_cmd_ ,head1_servo2_cmd_);
            //std::cout<<std::endl<<

            //仅当sound_start_为true时向电子组发送开始指令
            if (sound_start_ == true)
                hf_hw_.updateWriteCommand(SET_SOUND_START, count);

            hf_hw_.updateWriteCommand(SET_NECK, count);

            //std::cout<<"arm_cmd_:   "<<arm_cmd_[0]<<" "<<arm_cmd_[1]<<" "<<arm_cmd_[2]<<" "<<arm_cmd_[3]<<" "<<arm_cmd_[4]<<" "<<arm_cmd_[5]<<std::endl;
            //std::cout<<"arm_pos_:   "<<arm_pos_[0]<<" "<<arm_pos_[1]<<" "<<arm_pos_[2]<<" "<<arm_pos_[3]<<" "<<arm_pos_[4]<<" "<<arm_pos_[5]<<std::endl;

            //std::cout<<"finished   0"<<std::endl;
            if (with_arm_)
            {
                hf_hw_.updateWriteCommand(SET_ARM_TOTAL, count);
                hf_hw_.updateWriteCommand(PLAT_MOVE, count);
                hf_hw_.updateWriteCommand(SET_CLAW, count);
                //hf_hw_.updateWriteCommand(SET_WRIST, count);
                // due to we donnot call the chassis to return the gripper state to the handle
                // so we should manual update the handle for the /joint_state topic
                //gripper_pos_[0] = gripper_cmd_[0];
                //gripper_pos_[1] = gripper_cmd_[1];
            }

            //RobotAbstract类中的变量看作缓冲区
            writeBufferUpdate();

            std_msgs::Float32MultiArray msg;
            msg.data.push_back(0);
            msg.data.push_back(0);
            msg.data.push_back(0);
            msg.data.push_back(0.2);
            msg.data.push_back(0);
            msg.data.push_back(0);
            //test_pub.publish(msg);
            
            publishUltraSound();

            cm.update(ros::Time::now(), ros::Duration(1 / controller_freq_));

            // hf_hw_.updateCommand(SET_HEAD_1, count);

            //ros::spinOnce();
        }
        else
        {
            //底盘数据的模拟更新
            x_ += x_vel_ * cos(theta_) / controller_freq_;
            y_ += x_vel_ * sin(theta_) / controller_freq_;
            theta_ += theta_cmd_ / controller_freq_;

            x_vel_ = x_cmd_;
            y_vel_ = y_cmd_;
            theta_vel_ = theta_cmd_;
            //机械臂数据的模拟更新

            publishUltraSound();

            arm_pos_[0] = arm_cmd_[0];
            arm_pos_[1] = arm_cmd_[1];
            arm_pos_[2] = arm_cmd_[2];
            arm_pos_[3] = arm_cmd_[3];
            arm_pos_[4] = arm_cmd_[4];
            arm_pos_[5] = arm_cmd_[5];
            gripper_pos_[0] = gripper_cmd_[0];
            gripper_pos_[1] = gripper_cmd_[1];
            cm.update(ros::Time::now(), ros::Duration(1 / controller_freq_));

            //hehe.sleep();注释于1.27如果不注释，仿真时每次更新完都会睡眠一次，显示在rviz上就会感觉机器人特别卡
        }

        loop.sleep();
        count++;
        ros::spinOnce();
    }

    cm_spinner.stop();
    //hw_spinner.stop();
}
}; // namespace handsfree_hw
